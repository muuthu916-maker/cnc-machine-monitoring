# PS025 – Predictive Tool-Life Monitoring and Optimization System

**Sakthi Hackathon 2.0 | First-Year AI & ML Engineering Submission**  
**Track:** Industrial Automation, Artificial Intelligence & Machine Learning  

---

## 📌 Executive Summary

In high-precision Computerized Numerical Control (CNC) manufacturing, cutting tools are subject to extreme mechanical friction, cyclic shock loads, and high thermal gradients. Conventional shopfloor operators typically rely on either:
1. **Conservative Scheduled Replacement:** Discarding cutting inserts after fixed operating hours, resulting in up to **20–25% premature tool scrap** and wasted tooling budgets.
2. **Reactive Maintenance:** Running tools until visible surface chatter or catastrophic failure occurs, risking **expensive workpiece scrap, spindle bearing shock damage, and unplanned machine downtime**.

**PS025** is an AI-driven predictive tool-condition monitoring and Remaining Useful Life (RUL) optimization system. By analyzing multi-sensor telemetry (spindle speed, vibration harmonics, acoustic stress waves, load current, and tool temperature), the system predicts progressive flank wear ($VB$), estimates Remaining Useful Life in exact machining minutes and cycles, and issues prescriptive maintenance alerts before part quality is compromised.

---

## ⚙️ Key Technical Features

### 1. Real-Time Machine Monitoring
- **Machine Identification:** Monitored unit `MC-01` (Haas VF-2SS CNC Machining Center).
- **Machine Operational Status:** Live operational indicator (`Running` / `Feed-Hold` / `Idle`).
- **Telemetry Indicators:** Spindle Speed (RPM), Machining Operation (End Milling, Face Milling, Slotting), Workpiece Material (AISI 4140, Titanium, Aluminum), Feed Rate (mm/min), and Spindle Load (%).

### 2. High-Fidelity Physics-Based Data Simulation
- Generates realistic multi-stage tool degradation telemetry adhering to **Taylor's Tool Life Model**:
  - **Stage 1 (Break-In):** Initial rapid micro-wear (0 – 70 μm).
  - **Stage 2 (Steady State):** Linear progressive flank wear (70 – 220 μm).
  - **Stage 3 (Accelerated Wear):** Exponential failure zone (220 – 350+ μm).
- **Interactive Controls:** Advance machining cycles (+5 cycles), simulate accelerated tool wear slider (1 to 140 cycles), and reset brand new tool inserts.
- **Refresh Data Button:** Instantly regenerate stochastic sensor noise and thermal variations.
- **Honest Labeling:** All simulated telemetry is explicitly tagged with `DEMO / SIMULATED DATA`.

### 3. Signal Processing & Feature Extraction
- **Digital Noise Filtering:** Moving-average and low-pass smoothing to isolate true structural cutting dynamics.
- **Time-Domain Statistics:** Root Mean Square (RMS), Peak Amplitude, Crest Factor, Kurtosis, and Skewness.
- **Frequency-Domain FFT Spectrum:** Fast Fourier Transform (FFT) harmonic analysis isolating tooth-pass frequencies and resonance chatter.

### 4. AI/ML Remaining Useful Life (RUL) Prediction
- **Algorithm Architecture:** Dual-engine implementation featuring Physics-Guided Polynomial Ridge Regression and Random Forest Regression.
- **Model Validation Performance:**
  - **RUL Coefficient of Determination ($R^2$):** `0.9909`
  - **RUL Root Mean Square Error (RMSE):** `4.17 minutes`
  - **Flank Wear ($VB$) Estimation MAE:** `5.75 μm`
  - **Training Dataset:** 949 historical multi-machine machining cycles.
- **Uncertainty Quantification:** 95% Confidence Interval bounds calculated for every prediction.

### 5. Predictive Alert System & Prescriptive Recommendations
- **Multi-Tier Alert Thresholds:**
  - 🟢 **NORMAL (Healthy):** Flank wear $< 220\,\mu\text{m}$. Nominal cutting dynamics.
  - 🟡 **WARNING (Moderate Wear):** Flank wear $220\,\mu\text{m} \le VB < 280\,\mu\text{m}$. Planned tool changeover advised.
  - 🔴 **CRITICAL (Critical Wear):** Flank wear $\ge 280\,\mu\text{m}$. Immediate spindle feed-hold recommended to avoid scrap.
- **Configurable Thresholds:** Operators can dynamically tune warning and critical thresholds in micrometers ($\mu\text{m}$).
- **Optimal Replacement Timing:** Generates actionable prescriptive recommendations identifying optimal tool replacement windows during upcoming cycle changes.

### 6. Dual Data Management (CSV & SQLite)
- **Master Historical Dataset:** Pre-trained and exportable 949-record CSV database (`data/historical_machining_data.csv`).
- **One-Click Session CSV Export:** Download live session telemetry logs directly from the UI.
- **Embedded SQLite Logging:** Integrated database manager (`data/machining_telemetry.db`) for industrial audit trails.

---

## ⚠️ Important Architecture & Hardware Roadmap Notice

> [!IMPORTANT]
> **HARDWARE INTEGRATION NOTICE:**
> The physical hardware components—including the **ESP32 Dual-Core Microcontroller**, **ADXL345 3-Axis Digital Accelerometer**, and **Piezoelectric Acoustic Emission Transducer**—represent **planned future hardware integrations** designed for shopfloor retrofitting.
> 
> The current operational prototype runs on an industrial-grade physics-based telemetry simulator and AI/ML predictive regression models to validate real-time algorithms, user experience, and predictive accuracy for Sakthi Hackathon 2.0 demonstration. All data is clearly labeled as **DEMO / SIMULATED DATA**.

---

## 📁 Project Directory Structure

```text
PS025-Predictive-Tool-Life/
├── app.py                         # Full-featured Streamlit industrial dashboard
├── requirements.txt               # Python package dependencies
├── README.md                      # Complete project documentation & execution guide
├── data/
│   ├── historical_machining_data.csv   # Master 949-run machining dataset
│   ├── machining_telemetry.db          # SQLite operational database
│   └── test_verification_export.csv    # Export verification sample
├── models/
│   └── model_weights.json         # Trained ML regression model parameters
└── scripts/
    ├── data_simulator.py          # Physics-based CNC & sensor telemetry generator
    ├── ml_model.py                # Machine learning RUL & wear prediction engine
    ├── signal_processing.py       # Time-domain, filtering & FFT feature pipeline
    ├── db_manager.py              # SQLite database logging utility
    ├── standalone_dashboard.py    # Zero-dependency interactive web prototype
    └── test_pipeline.py           # Automated end-to-end test & validation suite
```

---

## 🚀 Execution Instructions (Windows)

### Option A: Run Full Streamlit Dashboard (Recommended)

1. **Open PowerShell / Command Prompt** in the project directory:
   ```powershell
   cd C:\Users\user\.gemini\antigravity\scratch\PS025-Predictive-Tool-Life
   ```

2. **Install Required Dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

3. **Launch the Streamlit Dashboard:**
   ```powershell
   streamlit run app.py
   ```
   *The application will automatically open in your default browser at `http://localhost:8501`.*

---

### Option B: Run Zero-Dependency Standalone Dashboard (Immediate Demonstration)

If Streamlit or Plotly is not yet installed in your Python environment, run the self-contained standalone prototype:

1. **Launch the Built-In Industrial Web Server:**
   ```powershell
   python scripts/standalone_dashboard.py
   ```

2. **Open Your Browser:**
   Navigate to:
   ```text
   http://localhost:8501
   ```
   *Runs natively using standard Python with NumPy and Pandas. Includes full live telemetry simulation, interactive sliders, dynamic Plotly-style canvas waveforms, FFT spectrum, alert thresholds, SQLite logging, and CSV export.*

---

### Option C: Run Automated System Verification Suite

To verify all system modules, telemetry models, ML accuracy metrics, and database logging in the terminal:
```powershell
python scripts/test_pipeline.py
```

Expected output:
```text
==============================================================================
PS025 – PREDICTIVE TOOL-LIFE MONITORING SYSTEM: VERIFICATION SUITE
Sakthi Hackathon 2.0 Prototype Engine Test
==============================================================================
[STEP 1] AI/ML Model Status & Performance:
  - Model Loaded: True
  - RUL Model R2 Score: 0.9909
  - RUL Model RMSE: 4.17 minutes
[STEP 2] Simulating Machine MC-01 Telemetry & Predictive Inference:
  >> Stage 1: Brand New Tool (Pristine Edge) -> Alert: NORMAL
  >> Stage 2: Steady-State Normal Cutting    -> Alert: WARNING
  >> Stage 3: High Wear / End-of-Life Zone   -> Alert: CRITICAL
[STEP 3] High-Frequency Signal Processing & FFT: 100% PASS
[STEP 4] SQLite Database Logging Check: 100% PASS
[STEP 5] CSV Export Check: 100% PASS
==============================================================================
ALL CORE SYSTEM MODULES VALIDATED SUCCESSFULLY (100% PASS)
==============================================================================
```

---

## 🎯 Demonstration Walkthrough for Hackathon Judges

1. **Initial State (New Tool):**
   - Machine `MC-01` displays **Status: Running** with high tool health (e.g., 85–95%) and estimated Remaining Useful Life of **~155 minutes**.
   - Alert indicator displays **SYSTEM NORMAL** (Green).
2. **Progressive Cutting Simulation:**
   - Drag the **Tool Usage (Machining Cycles)** slider to **Cycle 65** or click **▶ +5 Cycles**.
   - Notice the gradual rise in flank wear ($VB$), increased vibration RMS, and subtle temperature increase.
   - The AI/ML predictor updates RUL to **~105 minutes** with Tool Health around **60%**.
3. **Triggering Predictive Warning:**
   - Advance cycles past **Cycle 90** (flank wear $> 220\,\mu\text{m}$).
   - The status automatically switches to **SYSTEM WARNING** (Amber).
   - The prescriptive maintenance box outputs a recommended tool change window during the next cycle stop.
4. **Triggering Critical Alert:**
   - Advance cycles to **Cycle 125+** (flank wear $> 280\,\mu\text{m}$).
   - The alert immediately shifts to **SYSTEM CRITICAL** (Red) with an urgent replacement warning to prevent part scrap.
5. **Data Export & Audit:**
   - Click **📥 Download Session CSV** to export the recorded run log.
   - Click **💾 Log to SQLite DB** to verify industrial audit compliance.

---

## 🛠️ Technology Stack Summary

| Domain | Technology / Library | Role in Project |
| :--- | :--- | :--- |
| **Language** | Python 3.10+ | Core application logic and pipeline |
| **Dashboard UI** | Streamlit & Plotly | Interactive industrial dark-theme dashboard |
| **Data Engine** | Pandas & NumPy | Telemetry processing, dataframes & array math |
| **Machine Learning** | Scikit-learn & Ridge | Remaining Useful Life (RUL) regression & health index |
| **Signal Processing** | SciPy / NumPy FFT | Denoising, time-domain moments, and spectral FFT |
| **Storage** | CSV & SQLite | Historical dataset and relational operational logs |

---

*PS025 – Developed for Sakthi Hackathon 2.0*
