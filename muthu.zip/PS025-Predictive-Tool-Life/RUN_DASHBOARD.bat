@echo off
title PS025 - Predictive Tool-Life Monitoring System [Sakthi Hackathon 2.0]
color 0B

echo ==============================================================================
echo       PS025 - PREDICTIVE TOOL-LIFE MONITORING AND OPTIMIZATION SYSTEM
echo                   SAKTHI HACKATHON 2.0 PROTOTYPE LAUNCHER
echo ==============================================================================
echo.
echo [1/3] Checking Python installation on your computer...

where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PY_CMD=python
    goto :PYTHON_FOUND
)

where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PY_CMD=py
    goto :PYTHON_FOUND
)

echo.
echo [ERROR] Python is not found in your system PATH!
echo Please install Python 3.10 or higher from https://www.python.org/downloads/
echo (Make sure to check the box "Add Python to PATH" during installation).
echo.
pause
exit /b 1

:PYTHON_FOUND
echo [OK] Python found: %PY_CMD%
echo.
echo [2/3] Initializing PS025 Industrial Prototype Server...
echo       Machine Target: MC-01 (Haas VF-2SS CNC Center)
echo       Status: Running
echo.

REM Open browser after 2 seconds in background
start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8501"

echo [3/3] Server is live! Opening browser at:
echo       Local URL:   http://localhost:8501
echo.
echo ==============================================================================
echo Instructions:
echo  1. Enter your Email in the login screen.
echo  2. Select your designated role (e.g. Lead AI/ML Engineer).
echo  3. Click "Access Telemetry Dashboard" to monitor Machine MC-01.
echo.
echo Keep this terminal window open while using the application.
echo Press Ctrl + C to stop the server anytime.
echo ==============================================================================
echo.

%PY_CMD% scripts\standalone_dashboard.py 8501
pause
