"""
PS025: Predictive Tool-Life Monitoring and Optimization System
Module: SQLite Telemetry Database Manager
Stores real-time and historical machining telemetry records.
"""

import os
import sqlite3
import pandas as pd

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "machining_telemetry.db")

def init_db():
    """Initialize SQLite database table for telemetry logging."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS telemetry_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                machine_id TEXT,
                machine_status TEXT,
                tool_id TEXT,
                operation TEXT,
                material TEXT,
                cycle_number INTEGER,
                spindle_speed_rpm REAL,
                feed_rate_mmpm REAL,
                depth_of_cut_mm REAL,
                spindle_load_pct REAL,
                tool_temp_c REAL,
                vibration_composite_rms REAL,
                ae_rms_mv REAL,
                flank_wear_um REAL,
                predicted_rul_min REAL,
                tool_health_pct REAL,
                tool_condition TEXT,
                alert_status TEXT,
                data_source TEXT
            )
        """)
        conn.commit()

def log_telemetry_record(record: dict) -> int:
    """Insert a single cycle telemetry record into SQLite database."""
    init_db()
    with sqlite3.connect(DB_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO telemetry_records (
                machine_id, machine_status, tool_id, operation, material, cycle_number,
                spindle_speed_rpm, feed_rate_mmpm, depth_of_cut_mm, spindle_load_pct,
                tool_temp_c, vibration_composite_rms, ae_rms_mv, flank_wear_um,
                predicted_rul_min, tool_health_pct, tool_condition, alert_status, data_source
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            record.get("machine_id", "MC-01"),
            record.get("machine_status", "Running"),
            record.get("tool_id", "TL-CARB-01"),
            record.get("operation", "End Milling"),
            record.get("material", "AISI 4140 Alloy Steel"),
            int(record.get("cycle_number", 1)),
            float(record.get("spindle_speed_rpm", 3200.0)),
            float(record.get("feed_rate_mmpm", 450.0)),
            float(record.get("depth_of_cut_mm", 1.5)),
            float(record.get("spindle_load_pct", 45.0)),
            float(record.get("tool_temp_c", 55.0)),
            float(record.get("vibration_composite_rms", 0.85)),
            float(record.get("ae_rms_mv", 18.0)),
            float(record.get("flank_wear_um", 80.0)),
            float(record.get("predicted_rul_min", 120.0)),
            float(record.get("tool_health_pct", 85.0)),
            record.get("tool_condition", "Healthy"),
            record.get("alert_status", "NORMAL"),
            record.get("data_source", "DEMO / SIMULATED DATA")
        ))
        conn.commit()
        return cursor.lastrowid

def get_recent_records(limit: int = 50) -> pd.DataFrame:
    """Fetch recent telemetry records as a Pandas DataFrame."""
    init_db()
    with sqlite3.connect(DB_PATH) as conn:
        df = pd.read_sql_query(
            "SELECT * FROM telemetry_records ORDER BY id DESC LIMIT ?",
            conn,
            params=(limit,)
        )
    return df

if __name__ == "__main__":
    init_db()
    print(f"SQLite Telemetry Database initialized at {DB_PATH}")
