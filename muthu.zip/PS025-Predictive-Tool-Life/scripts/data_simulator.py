"""
PS025: Predictive Tool-Life Monitoring and Optimization System
Module: Physics-Based Machining Data & Sensor Signal Simulator
NOTE: Generates realistic illustrative demonstration telemetry for CNC operations.
ESP32, vibration, and acoustic emission sensors represent planned future hardware integrations.
"""

import os
import numpy as np
import pandas as pd

MACHINES = [
    {"id": "MC-01", "name": "Haas VF-2SS CNC Machining Center", "type": "Milling", "max_rpm": 12000},
    {"id": "MC-02", "name": "DMG MORI CMX 600V Vertical Mill", "type": "Milling", "max_rpm": 15000},
    {"id": "MC-03", "name": "Mazak Quick Turn 250 Lathe", "type": "Turning", "max_rpm": 4500}
]

OPERATIONS = ["End Milling", "Face Milling", "Slotting", "Rough Turning", "Finish Profiling"]
MATERIALS = ["AISI 4140 Alloy Steel", "Ti-6Al-4V Titanium", "Al 6061-T6 Aluminum", "Inconel 718 Superalloy"]
TOOL_TYPES = ["Solid Carbide TiAlN 4-Flute", "Carbide Indexable Insert APMT1604", "Ceramic High-Feed Insert"]

def generate_machining_cycle(machine_id: str = "MC-01",
                             tool_id: str = "TL-CARB-08",
                             cycle_number: int = 45,
                             max_cycles: int = 150,
                             operation: str = "Face Milling",
                             material: str = "AISI 4140 Alloy Steel",
                             spindle_speed_rpm: float = 3200.0,
                             feed_rate_mmpm: float = 480.0,
                             depth_of_cut_mm: float = 1.5) -> dict:
    """
    Generate physics-based simulated telemetry for a single machining cycle.
    Models tool wear progression, vibration signals, acoustic emissions, and thermal build-up.
    """
    # Normalized cycle progress (0.0 brand new to 1.0 expected end-of-life)
    progress = min(cycle_number / float(max_cycles), 1.25)

    # 3-Stage Flank Wear (VB) Model (microns)
    # Critical wear threshold is 350 um
    # Stage 1: Break-in (0 - 0.15 progress): rapid initial wear to ~70 um
    # Stage 2: Steady state (0.15 - 0.75 progress): linear wear ~70 um to ~220 um
    # Stage 3: Catastrophic accelerated wear (> 0.75 progress): exponential climb towards 350+ um
    if progress < 0.15:
        flank_wear_um = 20.0 + (progress / 0.15) * 50.0 + np.random.normal(0, 2)
    elif progress < 0.75:
        steady_frac = (progress - 0.15) / 0.60
        flank_wear_um = 70.0 + steady_frac * 150.0 + np.random.normal(0, 3)
    else:
        accel_frac = (progress - 0.75) / 0.25
        flank_wear_um = 220.0 + (accel_frac ** 1.8) * 160.0 + np.random.normal(0, 5)

    flank_wear_um = max(15.0, round(flank_wear_um, 2))
    flank_wear_mm = round(flank_wear_um / 1000.0, 4)

    # Cutting speed & feed factor
    speed_factor = spindle_speed_rpm / 3000.0
    feed_factor = feed_rate_mmpm / 400.0

    # Spindle motor load (%) & Current (Amps)
    base_load = 32.0 * speed_factor * feed_factor
    wear_load_penalty = (flank_wear_um / 350.0) ** 1.5 * 38.0
    spindle_load_pct = min(98.0, max(20.0, base_load + wear_load_penalty + np.random.normal(0, 1.2)))
    spindle_current_a = round(spindle_load_pct * 0.28, 2)

    # Temperature (°C)
    base_temp = 38.0 + depth_of_cut_mm * 8.0
    wear_temp_rise = (flank_wear_um / 350.0) * 55.0
    tool_temp_c = round(base_temp + wear_temp_rise + np.random.normal(0, 1.5), 1)

    # Vibration Signal Synthesis (X, Y, Z axis in g RMS)
    # Base vibration from spindle rotation + tooth pass harmonics + wear friction
    tooth_pass_freq_hz = (spindle_speed_rpm / 60.0) * 4  # 4-flute cutter
    wear_vibe_boost = 1.0 + 3.2 * ((flank_wear_um / 350.0) ** 2.2)

    vib_x_rms = round(float(0.45 * wear_vibe_boost + np.random.normal(0, 0.03)), 3)
    vib_y_rms = round(float(0.55 * wear_vibe_boost + np.random.normal(0, 0.04)), 3)
    vib_z_rms = round(float(0.38 * wear_vibe_boost + np.random.normal(0, 0.02)), 3)
    composite_vib_rms = round(float(np.sqrt(vib_x_rms**2 + vib_y_rms**2 + vib_z_rms**2)), 3)

    # Acoustic Emission (AE in mV RMS / AE Energy Index)
    ae_rms_mv = round(float(12.5 + 45.0 * ((flank_wear_um / 350.0) ** 2.5) + np.random.normal(0, 1.0)), 2)

    # Remaining Useful Life (RUL) estimation
    # Remaining machining minutes before VB reaches 350 um
    # Nominal tool life ~ 180 minutes of cutting time
    total_nominal_life_min = 180.0
    spent_life_min = (flank_wear_um / 350.0) * total_nominal_life_min
    true_rul_min = max(0.0, round(total_nominal_life_min - spent_life_min + np.random.normal(0, 2), 1))
    avg_cycle_duration_min = 2.4
    remaining_cycles = max(0, int(true_rul_min / avg_cycle_duration_min))

    # Tool Condition Classification & Alert Status
    if flank_wear_um < 120.0:
        tool_condition = "Healthy"
        alert_status = "NORMAL"
        recommendation = "Tool cutting edge is in pristine condition. Optimal surface finish."
    elif flank_wear_um < 260.0:
        tool_condition = "Moderate Wear"
        alert_status = "WARNING"
        recommendation = "Progressive flank wear detected. Schedule replacement during next shift break."
    else:
        tool_condition = "Critical Wear"
        alert_status = "CRITICAL"
        recommendation = "CRITICAL WEAR THRESHOLD EXCEEDED: Immediate tool change required to avoid part scrap or spindle damage."

    health_index = max(0.0, min(100.0, round((1.0 - (flank_wear_um / 350.0)) * 100.0, 1)))

    return {
        "machine_id": machine_id,
        "machine_status": "Running",
        "data_source": "DEMO / SIMULATED DATA",
        "tool_id": tool_id,
        "cycle_number": cycle_number,
        "max_cycles": max_cycles,
        "operation": operation,
        "material": material,
        "spindle_speed_rpm": spindle_speed_rpm,
        "feed_rate_mmpm": feed_rate_mmpm,
        "depth_of_cut_mm": depth_of_cut_mm,
        "spindle_load_pct": round(spindle_load_pct, 1),
        "spindle_current_a": spindle_current_a,
        "tool_temp_c": tool_temp_c,
        "vib_x_rms": vib_x_rms,
        "vib_y_rms": vib_y_rms,
        "vib_z_rms": vib_z_rms,
        "vibration_composite_rms": composite_vib_rms,
        "ae_rms_mv": ae_rms_mv,
        "flank_wear_um": flank_wear_um,
        "flank_wear_mm": flank_wear_mm,
        "tool_health_pct": health_index,
        "true_rul_min": true_rul_min,
        "remaining_cycles": remaining_cycles,
        "tool_condition": tool_condition,
        "alert_status": alert_status,
        "recommendation": recommendation
    }

def synthesize_high_rate_waveform(sampling_freq: float = 2000.0, duration_sec: float = 0.5,
                                  rpm: float = 3200.0, wear_level_um: float = 120.0):
    """
    Synthesize high-frequency vibration and acoustic emission time-series signals
    representing tooth-impact dynamics, structural harmonics, and friction chatter.
    """
    t = np.linspace(0, duration_sec, int(sampling_freq * duration_sec), endpoint=False)
    spindle_freq = rpm / 60.0
    tooth_pass_freq = spindle_freq * 4.0  # 4 cutting inserts

    # Wear severity scaling
    wear_factor = wear_level_um / 350.0

    # Primary tooth cutting impacts
    vibration = 0.4 * np.sin(2 * np.pi * tooth_pass_freq * t)
    # Higher harmonics (2x, 3x tooth pass)
    vibration += (0.15 + 0.35 * wear_factor) * np.sin(2 * np.pi * 2 * tooth_pass_freq * t + 0.5)
    vibration += (0.05 + 0.45 * (wear_factor**2)) * np.sin(2 * np.pi * 3 * tooth_pass_freq * t + 1.2)
    # Machine resonance around 380 Hz
    vibration += (0.1 + 0.6 * wear_factor) * np.sin(2 * np.pi * 380.0 * t)
    # Gaussian background noise
    vibration += np.random.normal(0, 0.08 + 0.12 * wear_factor, size=len(t))

    # Acoustic Emission (high-frequency stress waves 500 Hz to 1000 Hz)
    ae_signal = 10.0 * np.sin(2 * np.pi * 650.0 * t) * (1.0 + 0.5 * np.sin(2 * np.pi * tooth_pass_freq * t))
    ae_signal += (5.0 + 35.0 * (wear_factor ** 2.2)) * np.random.normal(0, 0.5, size=len(t))

    return t, vibration, ae_signal

def generate_historical_dataset(num_tools: int = 10, cycles_per_tool: int = 120, output_csv: str = None) -> pd.DataFrame:
    """Generate a rich historical dataset representing multiple tool lifecycles across machines."""
    records = []
    tool_counter = 1

    for tool_idx in range(num_tools):
        t_id = f"TL-CARB-{tool_counter:02d}"
        mach = MACHINES[tool_idx % len(MACHINES)]
        op = OPERATIONS[tool_idx % len(OPERATIONS)]
        mat = MATERIALS[tool_idx % len(MATERIALS)]
        base_rpm = 2800.0 + (tool_idx * 250) % 1800
        base_feed = 380.0 + (tool_idx * 45) % 240
        doc = 1.0 + ((tool_idx * 0.4) % 1.6)

        max_cycles = np.random.randint(90, 140)

        for cycle in range(1, max_cycles + 1):
            rec = generate_machining_cycle(
                machine_id=mach["id"],
                tool_id=t_id,
                cycle_number=cycle,
                max_cycles=max_cycles,
                operation=op,
                material=mat,
                spindle_speed_rpm=base_rpm,
                feed_rate_mmpm=base_feed,
                depth_of_cut_mm=doc
            )
            records.append(rec)
        tool_counter += 1

    df = pd.DataFrame(records)
    if output_csv:
        os.makedirs(os.path.dirname(os.path.abspath(output_csv)), exist_ok=True)
        df.to_csv(output_csv, index=False)
        print(f"Historical dataset generated: {len(df)} records saved to {output_csv}")
    return df

if __name__ == "__main__":
    out_path = os.path.join(os.path.dirname(__file__), "..", "data", "historical_machining_data.csv")
    generate_historical_dataset(num_tools=8, output_csv=out_path)
