"""
PS025: Predictive Tool-Life Monitoring and Optimization System
Module: Signal Processing & Feature Extraction
"""

import numpy as np

def moving_average_filter(signal: np.ndarray, window_size: int = 5) -> np.ndarray:
    """Apply a moving average filter to reduce high-frequency measurement noise."""
    if len(signal) < window_size:
        return signal
    cumsum = np.cumsum(np.insert(signal, 0, 0))
    filtered = (cumsum[window_size:] - cumsum[:-window_size]) / float(window_size)
    # Pad head to maintain original length
    pad = np.repeat(signal[0], window_size - 1)
    return np.concatenate((pad, filtered))

def extract_time_domain_features(signal: np.ndarray) -> dict:
    """
    Extract statistical time-domain features from vibration or acoustic emission signals.
    Features: RMS, Peak, Crest Factor, Kurtosis, Skewness, Variance.
    """
    signal = np.asarray(signal, dtype=float)
    if len(signal) == 0:
        return {
            "rms": 0.0, "peak": 0.0, "crest_factor": 0.0,
            "kurtosis": 3.0, "skewness": 0.0, "std_dev": 0.0
        }

    mean_val = np.mean(signal)
    std_val = np.std(signal)
    std_safe = std_val if std_val > 1e-9 else 1e-9

    rms = np.sqrt(np.mean(signal ** 2))
    peak = np.max(np.abs(signal))
    crest_factor = peak / (rms if rms > 1e-9 else 1e-9)

    # Standardized moments
    diff = signal - mean_val
    skewness = float(np.mean((diff / std_safe) ** 3))
    kurtosis = float(np.mean((diff / std_safe) ** 4))

    return {
        "rms": float(rms),
        "peak": float(peak),
        "crest_factor": float(crest_factor),
        "kurtosis": float(kurtosis),
        "skewness": float(skewness),
        "std_dev": float(std_val)
    }

def compute_fft_spectrum(signal: np.ndarray, sampling_rate_hz: float = 2000.0):
    """
    Calculate the Fast Fourier Transform (FFT) spectrum of the raw vibration/acoustic signal.
    Returns: frequencies (Hz), amplitudes.
    """
    n = len(signal)
    if n < 2:
        return np.array([0.0]), np.array([0.0])

    # Apply Hann window to mitigate spectral leakage
    window = np.hanning(n)
    windowed = signal * window

    fft_vals = np.fft.rfft(windowed)
    amplitudes = (2.0 / n) * np.abs(fft_vals)
    freqs = np.fft.rfftfreq(n, d=1.0 / sampling_rate_hz)

    return freqs, amplitudes

def extract_frequency_features(freqs: np.ndarray, amplitudes: np.ndarray) -> dict:
    """Extract dominant spectral peaks and total spectral energy."""
    if len(amplitudes) == 0:
        return {"dominant_frequency_hz": 0.0, "spectral_energy": 0.0}

    dominant_idx = np.argmax(amplitudes)
    dominant_freq = float(freqs[dominant_idx])
    spectral_energy = float(np.sum(amplitudes ** 2))

    return {
        "dominant_frequency_hz": dominant_freq,
        "spectral_energy": spectral_energy
    }

def calculate_tool_health_index(vibration_rms: float, ae_rms: float, 
                                 flank_wear_um: float, critical_wear_um: float = 350.0) -> float:
    """
    Calculate normalized Tool Health Index (0% to 100%).
    100% = Brand new tool with pristine cutting edge.
    0%   = Reached or exceeded critical wear threshold (catastrophic failure risk).
    """
    wear_fraction = flank_wear_um / critical_wear_um
    health_index = max(0.0, min(100.0, (1.0 - wear_fraction) * 100.0))
    return round(health_index, 1)
