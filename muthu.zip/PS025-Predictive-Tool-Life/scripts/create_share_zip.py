"""
PS025: Shareable Package Creator
Creates a lightweight, portable ZIP archive of the complete working software prototype.
"""

import os
import zipfile

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_ZIP = os.path.join(os.path.dirname(BASE_DIR), "PS025_Predictive_Tool_Life_Clean_Shareable.zip")

EXCLUDE_DIRS = {"__pycache__", "video"}
EXCLUDE_EXTS = {".pyc", ".wav"}

def make_zip():
    print(f"Creating clean shareable package from: {BASE_DIR}")
    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(BASE_DIR):
            # Exclude unwanted directories
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTS:
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, BASE_DIR)
                zf.write(full_path, arcname=os.path.join("PS025-Predictive-Tool-Life", rel_path))
                
    size_mb = os.path.getsize(OUTPUT_ZIP) / (1024 * 1024)
    print(f"ZIP created successfully: {OUTPUT_ZIP}")
    print(f"Package Size: {size_mb:.2f} MB")

if __name__ == "__main__":
    make_zip()
