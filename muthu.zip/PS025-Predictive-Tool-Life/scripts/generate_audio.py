"""
PS025: Audio & Narration Synthesis Pipeline
Synthesizes:
1. Professional English voiceover narration for all 9 scenes using Windows SAPI
2. Cinematic ambient industrial music bed (48 kHz stereo, sub-bass drone, metallic pulse, telemetry arpeggio)
3. Mixed final soundtrack with narration ducking
"""

import os
import json
import math
import wave
import struct
import subprocess

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO_DIR = os.path.join(BASE_DIR, "video", "audio")
SUBTITLES_DIR = os.path.join(BASE_DIR, "video", "subtitles")
os.makedirs(AUDIO_DIR, exist_ok=True)

SCRIPT_JSON = os.path.join(SUBTITLES_DIR, "narration_script.json")

def generate_voiceover_sapi():
    """Generate high-quality WAV narration files using Windows SAPI through PowerShell."""
    with open(SCRIPT_JSON, "r", encoding="utf-8") as f:
        scenes = json.load(f)

    print("Generating speech audio for 9 scenes using Windows SAPI...")
    for sc in scenes:
        sid = sc["scene_id"]
        narration = sc["narration"]
        out_wav = os.path.join(AUDIO_DIR, f"scene_{sid}.wav")
        # Clean text for speech
        clean_text = narration.replace('"', '`"').replace("'", "''")

        ps_cmd = f"""
$voice = New-Object -ComObject SAPI.SpVoice
$stream = New-Object -ComObject SAPI.SpFileStream
$stream.Open('{out_wav}', 3, $false)
$voice.AudioOutputStream = $stream
$voice.Rate = 0
$voice.Volume = 100
$voice.Speak('{clean_text}')
$stream.Close()
"""
        cmd = ["powershell", "-NoProfile", "-Command", ps_cmd]
        subprocess.run(cmd, check=True)
        size = os.path.getsize(out_wav)
        print(f"  [Scene {sid}] Generated {os.path.basename(out_wav)} ({size} bytes)")

def generate_cinematic_music_bed(output_path: str, duration_sec: float = 305.0, sample_rate: int = 44100):
    """
    Synthesize an industrial cinematic ambient music bed:
    - 55 Hz deep sub-bass drone with slow low-frequency oscillation
    - 110 Hz / 220 Hz metallic industrial pulse
    - High-tech cyber telemetry arpeggios
    - Stereo reverb emulation
    """
    print(f"Synthesizing 5-minute cinematic ambient music bed ({duration_sec}s @ {sample_rate}Hz)...")
    total_samples = int(duration_sec * sample_rate)
    
    # Open WAV writer (16-bit stereo)
    with wave.open(output_path, "wb") as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        
        chunk_size = 88200  # 2 seconds chunks
        num_chunks = int(math.ceil(total_samples / chunk_size))
        
        current_sample = 0
        for chunk_idx in range(num_chunks):
            chunk_len = min(chunk_size, total_samples - current_sample)
            frames = bytearray()
            
            for i in range(chunk_len):
                t = (current_sample + i) / float(sample_rate)
                
                # 1. Deep cinematic sub-bass drone (55 Hz + 82.5 Hz fifth)
                lfo = 0.5 + 0.5 * math.sin(2 * math.pi * 0.15 * t)
                drone = (0.28 * math.sin(2 * math.pi * 55.0 * t) + 
                         0.14 * math.sin(2 * math.pi * 82.41 * t) +
                         0.08 * math.sin(2 * math.pi * 110.0 * t)) * (0.7 + 0.3 * lfo)
                
                # 2. Rhythmic metallic pulse (1.0 Hz industrial heartbeat, 120 bpm)
                pulse_phase = (t * 2.0) % 1.0
                pulse_env = math.exp(-6.0 * pulse_phase)
                pulse = 0.18 * pulse_env * (math.sin(2 * math.pi * 140.0 * t) + 0.5 * math.sin(2 * math.pi * 280.0 * t))
                
                # 3. High-tech cyber telemetry arpeggio (F minor pentatonic: 349, 415, 466, 523, 622 Hz)
                arp_notes = [349.23, 415.30, 466.16, 523.25, 622.25, 698.46]
                note_idx = int(t * 3.0) % len(arp_notes)
                note_freq = arp_notes[note_idx]
                note_phase = (t * 3.0) % 1.0
                arp_env = math.exp(-8.0 * note_phase)
                arp = 0.08 * arp_env * math.sin(2 * math.pi * note_freq * t)
                
                # Stereo separation
                left = (drone + pulse * 0.9 + arp * 0.7) * 0.65
                right = (drone + pulse * 1.1 + arp * 1.1) * 0.65
                
                # Soft master fade in (first 3 sec) and fade out (last 5 sec)
                if t < 3.0:
                    fade = t / 3.0
                    left *= fade
                    right *= fade
                elif t > (duration_sec - 5.0):
                    fade = max(0.0, (duration_sec - t) / 5.0)
                    left *= fade
                    right *= fade
                    
                # Clip & quantize to 16-bit signed integer
                left_int = int(max(-32767, min(32767, left * 32767)))
                right_int = int(max(-32767, min(32767, right * 32767)))
                
                frames.extend(struct.pack("<hh", left_int, right_int))
                
            wav.writeframes(frames)
            current_sample += chunk_len
            
    print(f"Music bed generated: {output_path} ({os.path.getsize(output_path)} bytes)")

def mix_soundtrack():
    """Mix the background music and the scene narrations into a master continuous soundtrack."""
    music_path = os.path.join(AUDIO_DIR, "cinematic_music_bed.wav")
    master_path = os.path.join(AUDIO_DIR, "master_soundtrack.wav")
    
    with open(SCRIPT_JSON, "r", encoding="utf-8") as f:
        scenes = json.load(f)
        
    # Calculate scene start offsets in seconds
    # Each scene ~ 33.3 seconds (total 300 seconds)
    scene_offsets = []
    accum = 0.0
    for sc in scenes:
        scene_offsets.append((sc["scene_id"], accum))
        accum += sc["duration_sec"]
        
    print(f"Reading background music from {music_path}...")
    with wave.open(music_path, "rb") as mw:
        n_channels = mw.getnchannels()
        sampwidth = mw.getsampwidth()
        framerate = mw.getframerate()
        n_frames = mw.getnframes()
        raw_music = mw.readframes(n_frames)
        
    music_samples = struct.unpack(f"<{n_frames * 2}h", raw_music)
    mixed_samples = list(music_samples)
    
    # Overlay each scene narration
    for sid, offset_sec in scene_offsets:
        wav_file = os.path.join(AUDIO_DIR, f"scene_{sid}.wav")
        if not os.path.exists(wav_file):
            continue
            
        with wave.open(wav_file, "rb") as vw:
            v_rate = vw.getframerate()
            v_frames = vw.getnframes()
            v_raw = vw.readframes(v_frames)
            
        # Voice is mono 16-bit
        v_samples = struct.unpack(f"<{v_frames}h", v_raw)
        
        # Insert narration at 1.5 seconds into the scene
        insert_sample_idx = int((offset_sec + 1.5) * framerate) * 2  # stereo pairs
        
        # Resample factor if needed
        rate_ratio = framerate / float(v_rate)
        
        for vi in range(len(v_samples)):
            target_idx = insert_sample_idx + int(vi * rate_ratio) * 2
            if target_idx + 1 >= len(mixed_samples):
                break
                
            v_val = v_samples[vi] * 1.3  # voice boost
            # Duck music by 50% under voice
            m_l = mixed_samples[target_idx] * 0.45
            m_r = mixed_samples[target_idx + 1] * 0.45
            
            mixed_samples[target_idx] = int(max(-32767, min(32767, m_l + v_val)))
            mixed_samples[target_idx + 1] = int(max(-32767, min(32767, m_r + v_val)))
            
    # Write master soundtrack
    print(f"Writing master mixed soundtrack to {master_path}...")
    with wave.open(master_path, "wb") as out_w:
        out_w.setnchannels(2)
        out_w.setsampwidth(2)
        out_w.setframerate(framerate)
        out_w.writeframes(struct.pack(f"<{len(mixed_samples)}h", *mixed_samples))
        
    print(f"Master soundtrack created successfully: {master_path} ({os.path.getsize(master_path)} bytes)")

if __name__ == "__main__":
    generate_voiceover_sapi()
    music_out = os.path.join(AUDIO_DIR, "cinematic_music_bed.wav")
    generate_cinematic_music_bed(music_out, duration_sec=305.0)
    mix_soundtrack()
