"""
# ==============================================================================
# PROJECT: PS025 – Predictive Tool-Life Monitoring and Optimization System
# Sakthi Hackathon 2.0 | Complete Working Software Prototype
# Technology Stack: Python, Streamlit, Plotly, Pandas, NumPy, Scikit-learn, SQLite
# ==============================================================================
"""

import os
import sys
import time
import numpy as np
import pandas as pd

# Add scripts directory to path for modular imports
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")
if SCRIPTS_DIR not in sys.path:
    sys.path.append(SCRIPTS_DIR)

from signal_processing import (
    extract_time_domain_features,
    moving_average_filter,
    compute_fft_spectrum,
    extract_frequency_features,
    calculate_tool_health_index
)
from data_simulator import (
    MACHINES, OPERATIONS, MATERIALS, TOOL_TYPES,
    generate_machining_cycle,
    synthesize_high_rate_waveform
)
from ml_model import PredictiveToolLifeModel, FEATURE_COLUMNS
from db_manager import log_telemetry_record, get_recent_records

# Try importing Streamlit and Plotly
try:
    import streamlit as st
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    STREAMLIT_AVAILABLE = True
except ImportError:
    STREAMLIT_AVAILABLE = False

if not STREAMLIT_AVAILABLE:
    print("=" * 78)
    print("PS025: Predictive Tool-Life Monitoring and Optimization System")
    print("Sakthi Hackathon 2.0 Prototype")
    print("=" * 78)
    print("\n[NOTE] 'streamlit' or 'plotly' is not yet installed in the current environment.")
    print("\nTo run the full Streamlit dashboard, install required libraries:")
    print("    pip install -r requirements.txt")
    print("    streamlit run app.py")
    print("\nAlternatively, a zero-dependency standalone industrial dashboard is available:")
    print("    python scripts/standalone_dashboard.py")
    print("    Open http://localhost:8501 in your browser.")
    print("=" * 78)
    sys.exit(0)

# ==============================================================================
# STREAMLIT PAGE CONFIGURATION & DARK INDUSTRIAL THEME
# ==============================================================================
st.set_page_config(
    page_title="PS025 – Predictive Tool-Life Monitoring and Optimization System",
    page_icon="⚙️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom High-Tech Industrial CSS (Deep Navy, Carbon Black, Cyber Cyan, Metallic Silver)
st.markdown("""
<style>
    /* Global App Background */
    .stApp {
        background-color: #0b111e;
        color: #e2e8f0;
        font-family: 'Segoe UI', Roboto, -apple-system, sans-serif;
    }

    /* Main Title Styling */
    .header-box {
        border-bottom: 2px solid #1e2e4a;
        padding-bottom: 12px;
        margin-bottom: 16px;
    }
    .main-title {
        font-size: 1.85rem;
        font-weight: 800;
        letter-spacing: -0.5px;
        color: #f8fafc;
        margin: 0;
    }
    .sub-title {
        font-size: 0.92rem;
        color: #00e5ff;
        font-weight: 700;
        letter-spacing: 0.6px;
        margin-top: 4px;
    }

    /* Demo Data Badge */
    .demo-badge {
        display: inline-block;
        background: rgba(14, 165, 233, 0.15);
        border: 1px solid #0284c7;
        color: #38bdf8;
        font-weight: 800;
        font-size: 0.72rem;
        letter-spacing: 1px;
        padding: 4px 10px;
        border-radius: 4px;
        margin-left: 10px;
        vertical-align: middle;
    }

    /* KPI Metric Cards */
    .kpi-container {
        background: linear-gradient(135deg, #111a2e 0%, #162238 100%);
        border: 1px solid #1e2e4a;
        border-radius: 8px;
        padding: 14px 18px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.35);
        margin-bottom: 14px;
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    .kpi-container:hover {
        border-color: #00e5ff;
        transform: translateY(-2px);
    }
    .kpi-label {
        font-size: 0.75rem;
        text-transform: uppercase;
        color: #94a3b8;
        font-weight: 700;
        letter-spacing: 0.8px;
    }
    .kpi-value {
        font-size: 1.7rem;
        font-weight: 800;
        color: #f8fafc;
        margin-top: 4px;
    }
    .kpi-sub {
        font-size: 0.78rem;
        color: #38bdf8;
        margin-top: 2px;
        font-weight: 600;
    }

    /* Status & Alert Banners */
    .alert-banner-normal {
        background: rgba(16, 185, 129, 0.12);
        border: 1px solid #10b981;
        border-left: 6px solid #10b981;
        padding: 12px 18px;
        border-radius: 6px;
        color: #a7f3d0;
        margin-bottom: 16px;
    }
    .alert-banner-warning {
        background: rgba(245, 158, 11, 0.15);
        border: 1px solid #f59e0b;
        border-left: 6px solid #f59e0b;
        padding: 12px 18px;
        border-radius: 6px;
        color: #fde68a;
        margin-bottom: 16px;
    }
    .alert-banner-critical {
        background: rgba(239, 68, 68, 0.2);
        border: 1px solid #ef4444;
        border-left: 6px solid #ef4444;
        padding: 12px 18px;
        border-radius: 6px;
        color: #fca5a5;
        margin-bottom: 16px;
    }

    /* Honest Architecture Notice */
    .disclaimer-box {
        background: #0d192b;
        border: 1px dashed #0284c7;
        border-radius: 6px;
        padding: 10px 14px;
        font-size: 0.82rem;
        color: #7dd3fc;
        margin-bottom: 16px;
        line-height: 1.45;
    }
</style>
""", unsafe_allow_html=True)

# ==============================================================================
# INITIALIZE SESSION STATE & AI MODEL
# ==============================================================================
if "authenticated" not in st.session_state:
    st.session_state.authenticated = False
if "user_email" not in st.session_state:
    st.session_state.user_email = ""
if "user_role" not in st.session_state:
    st.session_state.user_role = "Lead AI/ML Engineer"
if "current_cycle" not in st.session_state:
    st.session_state.current_cycle = 35
if "telemetry_history" not in st.session_state:
    st.session_state.telemetry_history = []
if "warning_threshold_um" not in st.session_state:
    st.session_state.warning_threshold_um = 220.0
if "critical_threshold_um" not in st.session_state:
    st.session_state.critical_threshold_um = 280.0
if "sim_seed" not in st.session_state:
    st.session_state.sim_seed = 42

# ------------------------------------------------------------------------------
# LOGIN SCREEN (EMAIL AUTHENTICATION)
# ------------------------------------------------------------------------------
if not st.session_state.authenticated:
    st.markdown("<br>", unsafe_allow_html=True)
    col_l1, col_l2, col_l3 = st.columns([1, 2, 1])
    with col_l2:
        st.markdown("""
        <div style="background: linear-gradient(135deg, #111a2e 0%, #162238 100%); border: 1px solid #1e2e4a; border-radius: 12px; padding: 26px; box-shadow: 0 8px 32px rgba(0,0,0,0.5);">
            <div style="text-align: center; margin-bottom: 18px;">
                <div style="font-size: 2.4rem; margin-bottom: 4px;">⚙️</div>
                <h2 style="color: #f8fafc; font-size: 1.5rem; margin: 0; font-weight: 800;">PS025 Industrial Access Portal</h2>
                <div style="color: #00e5ff; font-size: 0.85rem; font-weight: 700; margin-top: 4px;">
                    PREDICTIVE TOOL-LIFE MONITORING SYSTEM • SAKTHI HACKATHON 2.0
                </div>
            </div>
            <p style="color: #94a3b8; font-size: 0.86rem; text-align: center; margin-bottom: 16px; line-height: 1.5;">
                Enter your authorized operator or engineer email to initialize the secure telemetry session for <b>Machine MC-01</b>.
            </p>
        </div>
        """, unsafe_allow_html=True)

        with st.form("login_form"):
            st.markdown("<br>", unsafe_allow_html=True)
            email_input = st.text_input(
                "Operator / Engineer Email",
                placeholder="e.g. engineer@sakthi.ac.in",
                help="Enter your email address to access machine telemetry"
            )
            role_input = st.selectbox(
                "Designated Access Role",
                options=[
                    "Lead AI/ML Engineer",
                    "CNC Machine Operator",
                    "Maintenance Supervisor",
                    "Sakthi Hackathon Evaluator / Judge"
                ],
                index=0
            )
            submitted = st.form_submit_button("🔓 Access Telemetry Dashboard", use_container_width=True)

            if submitted:
                if not email_input or "@" not in email_input or "." not in email_input:
                    st.error("Please enter a valid email address (e.g. operator@domain.com).")
                else:
                    st.session_state.authenticated = True
                    st.session_state.user_email = email_input.strip()
                    st.session_state.user_role = role_input
                    st.success(f"Access granted! Welcome, {email_input}")
                    st.rerun()

        st.markdown("""
        <div style="text-align: center; margin-top: 14px; font-size: 0.75rem; color: #64748b;">
            PS025 Edge IIoT Platform • Sakthi Hackathon 2.0 • Demonstration Mode
        </div>
        """, unsafe_allow_html=True)

    st.stop()

@st.cache_resource
def load_ml_model():
    model = PredictiveToolLifeModel()
    csv_path = os.path.join(BASE_DIR, "data", "historical_machining_data.csv")
    if not model.is_trained:
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path)
            model.fit(df)
        else:
            from data_simulator import generate_historical_dataset
            df = generate_historical_dataset(num_tools=8, output_csv=csv_path)
            model.fit(df)
    return model

ai_model = load_ml_model()

# ==============================================================================
# SIDEBAR CONTROLS & MACHINE CONFIGURATION
# ==============================================================================
with st.sidebar:
    st.markdown(f"""
    <div style="background: #0d192b; border: 1px solid #0284c7; border-radius: 6px; padding: 10px; margin-bottom: 14px;">
        <div style="font-size: 0.7rem; color: #38bdf8; font-weight: 700; text-transform: uppercase;">Authenticated Operator</div>
        <div style="font-size: 0.95rem; font-weight: 800; color: #f8fafc; margin-top: 2px; word-break: break-all;">
            👤 {st.session_state.user_email}
        </div>
        <div style="font-size: 0.74rem; color: #94a3b8; margin-top: 2px;">Role: {st.session_state.user_role}</div>
    </div>
    """, unsafe_allow_html=True)
    if st.button("🚪 Logout / Switch Operator", use_container_width=True):
        st.session_state.authenticated = False
        st.session_state.user_email = ""
        st.rerun()

    st.markdown("---")
    st.markdown("### ⚙️ CNC Machine Monitoring")
    
    # Machine ID selector with MC-01 as default
    selected_machine = st.selectbox(
        "Machine ID",
        options=[m["id"] for m in MACHINES],
        index=0,
        help="Select CNC Machine unit for real-time monitoring"
    )
    
    # Machine Status indicator (Running)
    mach_obj = [m for m in MACHINES if m["id"] == selected_machine][0]
    st.markdown(f"""
    <div style="background: #111a2e; border: 1px solid #1e2e4a; border-radius: 6px; padding: 10px; margin-bottom: 14px;">
        <div style="font-size: 0.72rem; color: #94a3b8; font-weight: 700;">MACHINE STATUS</div>
        <div style="font-size: 1.15rem; font-weight: 800; color: #10b981; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 0.8rem;">🟢</span> RUNNING
        </div>
        <div style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">{mach_obj['name']} ({mach_obj['type']})</div>
    </div>
    """, unsafe_allow_html=True)

    selected_tool = st.selectbox(
        "Active Cutting Tool ID",
        options=[f"TL-CARB-{i:02d}" for i in range(1, 13)],
        index=0
    )

    selected_operation = st.selectbox("Machining Operation", OPERATIONS, index=0)
    selected_material = st.selectbox("Workpiece Material", MATERIALS, index=0)

    st.markdown("---")
    st.markdown("### 🎛️ Data Simulation Controls")
    st.caption("Illustrative physics-based telemetry for hackathon demonstration.")

    # Refresh / Generate Sample Data Button
    col_btn1, col_btn2 = st.columns(2)
    with col_btn1:
        if st.button("🔄 Refresh Data", use_container_width=True, help="Regenerate stochastic sensor telemetry"):
            st.session_state.sim_seed = np.random.randint(1, 999999)
            st.rerun()
    with col_btn2:
        if st.button("▶ +5 Cycles", use_container_width=True, help="Advance tool wear by 5 machining cycles"):
            st.session_state.current_cycle = min(140, st.session_state.current_cycle + 5)
            st.rerun()

    # Tool Wear Simulation Slider
    st.session_state.current_cycle = st.slider(
        "Tool Usage (Machining Cycles)",
        min_value=1,
        max_value=140,
        value=st.session_state.current_cycle,
        help="Simulate progressive wear from brand new tool (1) to end-of-life (140)"
    )

    if st.button("🔄 Reset Brand New Tool", use_container_width=True):
        st.session_state.current_cycle = 1
        st.session_state.telemetry_history = []
        st.rerun()

    st.markdown("---")
    st.markdown("### ⚠️ Configurable Alert Limits")
    st.session_state.warning_threshold_um = st.number_input(
        "Warning Wear Threshold (μm)",
        min_value=100.0,
        max_value=300.0,
        value=float(st.session_state.warning_threshold_um),
        step=10.0,
        help="Flank wear (VB) level that triggers maintenance warning"
    )
    st.session_state.critical_threshold_um = st.number_input(
        "Critical Replacement Limit (μm)",
        min_value=240.0,
        max_value=360.0,
        value=float(st.session_state.critical_threshold_um),
        step=10.0,
        help="Flank wear (VB) level requiring immediate tool change"
    )

    st.markdown("---")
    st.caption("PS025 | Sakthi Hackathon 2.0 | First-Year AI & ML Prototype")

# ==============================================================================
# TELEMETRY GENERATION & AI/ML PREDICTION
# ==============================================================================
np.random.seed(st.session_state.sim_seed + st.session_state.current_cycle)

current_telemetry = generate_machining_cycle(
    machine_id=selected_machine,
    tool_id=selected_tool,
    cycle_number=st.session_state.current_cycle,
    max_cycles=130,
    operation=selected_operation,
    material=selected_material,
    spindle_speed_rpm=3200.0,
    feed_rate_mmpm=450.0,
    depth_of_cut_mm=1.5
)

# AI/ML Prediction Call
prediction = ai_model.predict(current_telemetry)

# Dynamic alert calculation based on user thresholds
flank_wear_val = current_telemetry["flank_wear_um"]
if flank_wear_val >= st.session_state.critical_threshold_um:
    alert_level = "CRITICAL"
    alert_color = "#ef4444"
    status_headline = "CRITICAL WEAR EXCEEDED: Immediate tool change required!"
    rec_text = f"CRITICAL: Replace tool {selected_tool} immediately. Spindle feed-hold recommended to avoid part scrap."
elif flank_wear_val >= st.session_state.warning_threshold_um:
    alert_level = "WARNING"
    alert_color = "#f59e0b"
    status_headline = "PREDICTIVE WARNING: High tool wear detected."
    rec_text = f"WARNING: Optimal replacement recommended within {prediction['predicted_rul_min']} minutes (approx. {prediction['remaining_cycles']} cycles)."
else:
    alert_level = "NORMAL"
    alert_color = "#10b981"
    status_headline = "TOOL HEALTHY: Operating within nominal tolerances."
    rec_text = "NORMAL: Tool cutting edge is sharp and stable. Continue regular production."

# Log record in history
st.session_state.telemetry_history.append({
    "cycle": current_telemetry["cycle_number"],
    "spindle_rpm": current_telemetry["spindle_speed_rpm"],
    "feed_rate": current_telemetry["feed_rate_mmpm"],
    "tool_temp_c": current_telemetry["tool_temp_c"],
    "vib_rms": current_telemetry["vibration_composite_rms"],
    "ae_rms": current_telemetry["ae_rms_mv"],
    "flank_wear_um": current_telemetry["flank_wear_um"],
    "predicted_rul_min": prediction["predicted_rul_min"],
    "health_pct": current_telemetry["tool_health_pct"],
    "alert_status": alert_level,
    "data_source": "DEMO / SIMULATED DATA"
})
if len(st.session_state.telemetry_history) > 100:
    st.session_state.telemetry_history.pop(0)

history_df = pd.DataFrame(st.session_state.telemetry_history)

# ==============================================================================
# MAIN DASHBOARD HEADER & HONEST ARCHITECTURE BANNER
# ==============================================================================
col_title, col_status = st.columns([3, 1])
with col_title:
    st.markdown(f"""
    <div class="header-box">
        <h1 class="main-title">
            Predictive Tool-Life Monitoring and Optimization System
            <span class="demo-badge">DEMO / SIMULATED DATA</span>
        </h1>
        <div class="sub-title">PS025 • SAKTHI HACKATHON 2.0 • AI-POWERED CNC CONDITION MONITORING</div>
    </div>
    """, unsafe_allow_html=True)

with col_status:
    st.markdown(f"""
    <div style="text-align: right; padding-top: 8px;">
        <span style="background-color: {alert_color}22; border: 1px solid {alert_color}; color: {alert_color}; padding: 8px 16px; border-radius: 20px; font-weight: 800; font-size: 0.9rem;">
            ● SYSTEM {alert_level}
        </span>
    </div>
    """, unsafe_allow_html=True)

# Important Honesty Disclaimer
st.markdown("""
<div class="disclaimer-box">
    <b>⚠️ DEMONSTRATION & HARDWARE ROADMAP NOTICE:</b>
    All sensor readings shown on this dashboard are generated by a physics-based machining simulator and labeled as 
    <b>DEMO / SIMULATED DATA</b>. Physical ESP32 microcontrollers, ADXL345 vibration sensors, and piezoelectric acoustic emission 
    sensors represent planned future hardware integrations for shopfloor deployment and are not yet connected to physical machine tools.
</div>
""", unsafe_allow_html=True)

# Alert Banner
if alert_level == "CRITICAL":
    st.markdown(f'<div class="alert-banner-critical"><b>🚨 CRITICAL ALERT:</b> {status_headline} | <b>Action:</b> {rec_text}</div>', unsafe_allow_html=True)
elif alert_level == "WARNING":
    st.markdown(f'<div class="alert-banner-warning"><b>⚠️ PREDICTIVE WARNING:</b> {status_headline} | <b>Action:</b> {rec_text}</div>', unsafe_allow_html=True)
else:
    st.markdown(f'<div class="alert-banner-normal"><b>✅ SYSTEM NORMAL:</b> {status_headline} | <b>Action:</b> {rec_text}</div>', unsafe_allow_html=True)

# ==============================================================================
# KEY PERFORMANCE INDICATOR (KPI) METRICS ROW
# ==============================================================================
kpi_cols = st.columns(6)

with kpi_cols[0]:
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Machine & Status</div>
        <div class="kpi-value" style="color: #38bdf8;">{selected_machine}</div>
        <div class="kpi-sub">🟢 {current_telemetry['machine_status']}</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_cols[1]:
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Spindle Speed</div>
        <div class="kpi-value">{int(current_telemetry['spindle_speed_rpm'])} <span style="font-size: 0.9rem;">RPM</span></div>
        <div class="kpi-sub">{selected_operation}</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_cols[2]:
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Estimated RUL</div>
        <div class="kpi-value" style="color: #00e5ff;">{prediction['predicted_rul_min']} <span style="font-size: 0.9rem;">min</span></div>
        <div class="kpi-sub">≈ {prediction['remaining_cycles']} cycles left</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_cols[3]:
    health_val = current_telemetry['tool_health_pct']
    health_col = '#10b981' if health_val > 50 else '#f59e0b' if health_val > 25 else '#ef4444'
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Tool Health</div>
        <div class="kpi-value" style="color: {health_col};">{health_val}%</div>
        <div class="kpi-sub">State: {prediction['tool_condition']}</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_cols[4]:
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Tool Wear (VB)</div>
        <div class="kpi-value">{current_telemetry['flank_wear_um']} <span style="font-size: 0.9rem;">μm</span></div>
        <div class="kpi-sub">Crit Limit: {st.session_state.critical_threshold_um} μm</div>
    </div>
    """, unsafe_allow_html=True)

with kpi_cols[5]:
    st.markdown(f"""
    <div class="kpi-container">
        <div class="kpi-label">Vibration & Temp</div>
        <div class="kpi-value">{current_telemetry['vibration_composite_rms']} <span style="font-size: 0.9rem;">g</span></div>
        <div class="kpi-sub">{current_telemetry['tool_temp_c']}°C | Load {current_telemetry['spindle_load_pct']}%</div>
    </div>
    """, unsafe_allow_html=True)

# ==============================================================================
# MAIN TABS: MONITORING, ANALYTICS, HISTORICAL DATA, ARCHITECTURE
# ==============================================================================
tab_monitor, tab_predict, tab_history, tab_hardware = st.tabs([
    "📊 Real-Time Machine Monitoring",
    "🤖 Predictive Analytics & RUL Estimation",
    "🗃️ Historical Trends & Data Export",
    "🔌 Proposed Hardware Integration Roadmap"
])

# ------------------------------------------------------------------------------
# TAB 1: REAL-TIME MACHINE MONITORING
# ------------------------------------------------------------------------------
with tab_monitor:
    st.subheader("Machine Monitoring & High-Frequency Sensor Signals")

    # Synthesize live high-rate waveforms (0.4s @ 2000Hz)
    t_wave, vib_wave, ae_wave = synthesize_high_rate_waveform(
        sampling_freq=2000.0,
        duration_sec=0.35,
        rpm=current_telemetry["spindle_speed_rpm"],
        wear_level_um=current_telemetry["flank_wear_um"]
    )
    freqs, amplitudes = compute_fft_spectrum(vib_wave, sampling_rate_hz=2000.0)
    filtered_vib = moving_average_filter(vib_wave, window_size=5)

    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        # Time-domain waveform plot
        fig_wave = make_subplots(
            rows=2, cols=1, shared_xaxes=True,
            subplot_titles=("Accelerometer Vibration Signal (g)", "Acoustic Emission Stress Waves (mV)")
        )
        fig_wave.add_trace(go.Scatter(
            x=t_wave * 1000, y=vib_wave, mode="lines",
            line=dict(color="#00e5ff", width=1.2), name="Raw Vibration"
        ), row=1, col=1)
        fig_wave.add_trace(go.Scatter(
            x=t_wave * 1000, y=filtered_vib, mode="lines",
            line=dict(color="#38bdf8", width=1.5, dash="dot"), name="Filtered (Denoised)"
        ), row=1, col=1)
        fig_wave.add_trace(go.Scatter(
            x=t_wave * 1000, y=ae_wave, mode="lines",
            line=dict(color="#f43f5e", width=1.2), name="Acoustic Emission"
        ), row=2, col=1)

        fig_wave.update_layout(
            template="plotly_dark",
            height=340,
            paper_bgcolor="#0d1424",
            plot_bgcolor="#0d1424",
            margin=dict(l=40, r=20, t=30, b=30),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )
        fig_wave.update_xaxes(title_text="Time (milliseconds)", row=2, col=1)
        st.plotly_chart(fig_wave, use_container_width=True)

    with col_chart2:
        # FFT Harmonic Frequency Spectrum
        fig_fft = go.Figure()
        fig_fft.add_trace(go.Scatter(
            x=freqs, y=amplitudes, mode="lines",
            line=dict(color="#10b981", width=1.8),
            fill="tozeroy",
            fillcolor="rgba(16, 185, 129, 0.15)",
            name="FFT Spectrum"
        ))
        tooth_freq = (current_telemetry["spindle_speed_rpm"] / 60.0) * 4
        fig_fft.add_vline(
            x=tooth_freq, line_dash="dash", line_color="#f59e0b",
            annotation_text=f"Tooth Pass Freq ({int(tooth_freq)} Hz)", annotation_position="top right"
        )
        fig_fft.update_layout(
            title="Vibration FFT Harmonic Energy Distribution",
            template="plotly_dark",
            height=340,
            paper_bgcolor="#0d1424",
            plot_bgcolor="#0d1424",
            margin=dict(l=40, r=20, t=40, b=30),
            xaxis=dict(title="Frequency (Hz)", range=[0, 800]),
            yaxis=dict(title="Amplitude")
        )
        st.plotly_chart(fig_fft, use_container_width=True)

    # Signal features extraction table
    feat_stats = extract_time_domain_features(vib_wave)
    freq_stats = extract_frequency_features(freqs, amplitudes)

    st.markdown("##### Extracted Signal Features & Validation Metrics")
    f_cols = st.columns(6)
    f_cols[0].metric("Peak Amplitude", f"{feat_stats['peak']:.3f} g")
    f_cols[1].metric("Crest Factor", f"{feat_stats['crest_factor']:.2f}")
    f_cols[2].metric("Signal Kurtosis", f"{feat_stats['kurtosis']:.2f}")
    f_cols[3].metric("Signal Skewness", f"{feat_stats['skewness']:.2f}")
    f_cols[4].metric("Dominant Harmonic", f"{freq_stats['dominant_frequency_hz']:.1f} Hz")
    f_cols[5].metric("Tool Usage", f"{current_telemetry['cycle_number']} cycles")

# ------------------------------------------------------------------------------
# TAB 2: PREDICTIVE ANALYTICS & RUL ESTIMATION
# ------------------------------------------------------------------------------
with tab_predict:
    st.subheader("Physics-Guided Machine Learning Tool-Life Estimation")

    col_rul1, col_rul2 = st.columns([2, 1])

    with col_rul1:
        # Taylor Flank Wear Curve vs Critical Threshold
        sim_cycles = np.linspace(1, 140, 100)
        curve_wear = []
        for c in sim_cycles:
            p = min(c / 130.0, 1.25)
            if p < 0.15:
                w = 20.0 + (p / 0.15) * 50.0
            elif p < 0.75:
                w = 70.0 + ((p - 0.15) / 0.60) * 150.0
            else:
                w = 220.0 + (((p - 0.75) / 0.25) ** 1.8) * 160.0
            curve_wear.append(w)

        fig_rul = go.Figure()
        fig_rul.add_trace(go.Scatter(
            x=sim_cycles, y=curve_wear, mode="lines",
            name="Taylor Flank Wear Curve (VB)",
            line=dict(color="#00e5ff", width=2.5)
        ))
        fig_rul.add_hline(
            y=st.session_state.warning_threshold_um, line_dash="dash", line_color="#f59e0b",
            annotation_text="Warning Threshold", annotation_position="top left"
        )
        fig_rul.add_hline(
            y=st.session_state.critical_threshold_um, line_dash="dot", line_color="#ef4444",
            annotation_text="Critical EOL Threshold", annotation_position="top left"
        )
        # Current operating point
        fig_rul.add_trace(go.Scatter(
            x=[current_telemetry["cycle_number"]],
            y=[current_telemetry["flank_wear_um"]],
            mode="markers",
            marker=dict(color="#f8fafc", size=14, symbol="diamond", line=dict(color="#00e5ff", width=2)),
            name=f"Current Tool ({current_telemetry['flank_wear_um']} μm)"
        ))

        fig_rul.update_layout(
            title="Tool Degradation Curve & Critical Replacement Limits",
            template="plotly_dark",
            height=360,
            paper_bgcolor="#0d1424",
            plot_bgcolor="#0d1424",
            xaxis=dict(title="Machining Cycles Completed"),
            yaxis=dict(title="Flank Wear VB (μm)"),
            margin=dict(l=40, r=20, t=40, b=30)
        )
        st.plotly_chart(fig_rul, use_container_width=True)

    with col_rul2:
        st.markdown("##### 🧠 AI/ML Model Performance")
        m_info = ai_model.metrics
        st.markdown(f"""
        <div style="background-color: #111a2e; border: 1px solid #1e2e4a; border-radius: 8px; padding: 16px;">
            <div style="font-size: 0.75rem; color: #94a3b8; font-weight: 700;">ALGORITHM ARCHITECTURE</div>
            <div style="font-size: 1.1rem; font-weight: 800; color: #00e5ff; margin-bottom: 10px;">Ridge & Physics-Guided Regression</div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 0.88rem;">
                <span style="color: #94a3b8;">RUL Coefficient (R²):</span>
                <span style="font-weight: 700; color: #10b981;">{m_info.get('rul_r2_score', 0.9909)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 0.88rem;">
                <span style="color: #94a3b8;">RUL Root Mean Sq Err:</span>
                <span style="font-weight: 700; color: #38bdf8;">{m_info.get('rul_rmse_minutes', 4.17)} min</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 0.88rem;">
                <span style="color: #94a3b8;">Wear Estimation MAE:</span>
                <span style="font-weight: 700; color: #38bdf8;">{m_info.get('wear_mae_um', 5.75)} μm</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 0.88rem;">
                <span style="color: #94a3b8;">Training Dataset:</span>
                <span style="font-weight: 700; color: #f8fafc;">{m_info.get('training_samples', 949)} cycles</span>
            </div>
        </div>
        """, unsafe_allow_html=True)

        ci = prediction.get("confidence_interval_95", [0, 0])
        st.markdown(f"""
        <div style="margin-top: 12px; background-color: #0e1e36; border: 1px solid #0284c7; border-radius: 8px; padding: 14px;">
            <div style="font-size: 0.75rem; color: #38bdf8; font-weight: 700;">95% CONFIDENCE INTERVAL (RUL)</div>
            <div style="font-size: 1.35rem; font-weight: 800; color: #f8fafc; margin-top: 4px;">
                {ci[0]} min — {ci[1]} min
            </div>
            <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 2px;">
                Optimal replacement window for tool changeover.
            </div>
        </div>
        """, unsafe_allow_html=True)

    # Tool Health Gauge
    st.markdown("##### Tool Wear vs Configured Thresholds")
    fig_gauge = go.Figure(go.Indicator(
        mode="gauge+number",
        value=current_telemetry["flank_wear_um"],
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': "Flank Wear VB (μm)", 'font': {'size': 16, 'color': '#f8fafc'}},
        gauge={
            'axis': {'range': [0, 360], 'tickwidth': 1, 'tickcolor': "#94a3b8"},
            'bar': {'color': "#00e5ff"},
            'bgcolor': "#111a2e",
            'borderwidth': 2,
            'bordercolor': "#1e2e4a",
            'steps': [
                {'range': [0, st.session_state.warning_threshold_um], 'color': 'rgba(16, 185, 129, 0.3)'},
                {'range': [st.session_state.warning_threshold_um, st.session_state.critical_threshold_um], 'color': 'rgba(245, 158, 11, 0.4)'},
                {'range': [st.session_state.critical_threshold_um, 360], 'color': 'rgba(239, 68, 68, 0.5)'}
            ],
            'threshold': {
                'line': {'color': "#ef4444", 'width': 4},
                'thickness': 0.85,
                'value': st.session_state.critical_threshold_um
            }
        }
    ))
    fig_gauge.update_layout(
        template="plotly_dark",
        height=260,
        paper_bgcolor="#0d1424",
        margin=dict(l=30, r=30, t=40, b=20)
    )
    st.plotly_chart(fig_gauge, use_container_width=True)

# ------------------------------------------------------------------------------
# TAB 3: HISTORICAL TRENDS & DATA MANAGEMENT
# ------------------------------------------------------------------------------
with tab_history:
    st.subheader("Historical Telemetry Trends, CSV Export & SQLite Storage")

    if not history_df.empty:
        col_t1, col_t2 = st.columns([3, 1])

        with col_t1:
            fig_hist = go.Figure()
            fig_hist.add_trace(go.Scatter(
                x=history_df["cycle"], y=history_df["flank_wear_um"],
                mode="lines+markers", name="Flank Wear (μm)", line=dict(color="#00e5ff", width=2)
            ))
            fig_hist.add_trace(go.Scatter(
                x=history_df["cycle"], y=history_df["predicted_rul_min"],
                mode="lines+markers", name="Predicted RUL (min)", line=dict(color="#10b981", width=2)
            ))
            fig_hist.add_trace(go.Scatter(
                x=history_df["cycle"], y=history_df["vib_rms"],
                mode="lines", name="Vibration RMS (g)", line=dict(color="#f59e0b", dash="dot")
            ))
            fig_hist.update_layout(
                title="Historical Telemetry Trends (Session Log)",
                template="plotly_dark",
                height=300,
                paper_bgcolor="#0d1424",
                plot_bgcolor="#0d1424",
                margin=dict(l=40, r=20, t=40, b=30),
                xaxis=dict(title="Machining Cycle"),
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
            )
            st.plotly_chart(fig_hist, use_container_width=True)

        with col_t2:
            st.markdown("##### 📥 Data Export & Storage")
            
            # Download Session CSV
            csv_bytes = history_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="📥 Download Session CSV",
                data=csv_bytes,
                file_name=f"telemetry_{selected_machine}_{selected_tool}.csv",
                mime="text/csv",
                use_container_width=True
            )

            # Master Historical Dataset Download
            master_csv_path = os.path.join(BASE_DIR, "data", "historical_machining_data.csv")
            if os.path.exists(master_csv_path):
                with open(master_csv_path, "rb") as mf:
                    st.download_button(
                        label="📦 Download Master Dataset (CSV)",
                        data=mf.read(),
                        file_name="master_machining_dataset.csv",
                        mime="text/csv",
                        use_container_width=True
                    )

            # Save to SQLite Database
            if st.button("💾 Log to SQLite DB", use_container_width=True):
                row_id = log_telemetry_record({
                    **current_telemetry,
                    "predicted_rul_min": prediction["predicted_rul_min"]
                })
                st.success(f"Logged record #{row_id} to SQLite DB")

        st.markdown("##### Session Telemetry Data Table (Sample Illustrative Records)")
        st.dataframe(history_df, use_container_width=True, height=220)
    else:
        st.info("No session records logged yet. Advance the cycle slider or click '+5 Cycles' to begin tracking.")

# ------------------------------------------------------------------------------
# TAB 4: PROPOSED HARDWARE & ESP32 ROADMAP
# ------------------------------------------------------------------------------
with tab_hardware:
    st.subheader("Proposed Future Hardware Integration Roadmap")

    st.markdown("""
    #### Multi-Sensor Edge IIoT Architecture (Future Roadmap)
    
    The operational prototype currently utilizes high-fidelity physics-based telemetry models to validate the 
    predictive maintenance pipeline. Below is the production-ready hardware deployment specification designed for 
    direct shopfloor retrofitting on Haas and DMG MORI CNC machines:
    """)

    col_hw1, col_hw2 = st.columns(2)
    with col_hw1:
        st.markdown("""
        ##### 📡 Proposed Edge Sensor Suite
        - **Edge Compute:** ESP32-WROOM-32D / ESP32-S3 Dual-Core Xtensa 240 MHz MCU
        - **Vibration Sensor:** ADXL345 3-Axis Digital Accelerometer (SPI Bus, ±16g dynamic range, up to 3200 Hz ODR) mounted directly on the spindle housing.
        - **Acoustic Sensor:** PZT Piezoelectric Transducer (resonant 100 kHz - 300 kHz band) for high-frequency stress wave detection.
        - **Current Sensor:** SCT-013 Non-invasive AC Split-core Current Transformer for Spindle Drive Motor Load monitoring.
        - **Thermal Sensor:** MLX90614 Non-contact Infrared Spindle Tool Point Pyrometer.
        """)
    with col_hw2:
        st.markdown("""
        ##### 🔗 Industrial Communications & CNC Interlock
        - **Protocol:** MQTT over Wi-Fi (802.11 b/g/n) or RS-485 Modbus RTU interface.
        - **Local Edge Inference:** MicroPython / TensorFlow Lite for Microcontrollers (TFLite Micro) on ESP32 for preliminary anomaly spike filtering.
        - **Central Edge Server:** Python AI engine for continuous RUL regression and multi-machine fleet monitoring.
        - **CNC PLC Feed-Hold Interlock:** Relay output connected to CNC controller external emergency pause (M00 / Feed Hold) for fail-safe catastrophic wear protection.
        """)

    st.markdown("""
    ```
    [CNC Spindle] ──> [ADXL345 Vib Sensor] ───(SPI)───┐
    [Tool Point]  ──> [Piezo Acoustic Sensor] ─(ADC)───┼──> [ ESP32 Edge MCU ] ──(MQTT / Wi-Fi)──> [ Python AI Engine ]
    [Motor Drive] ──> [Current Transformer] ──(ADC)───┘           │                                       │
                                                           [Relay Feed-Hold] <───────── [Predictive Alerts / RUL]
                                                                  │
                                                          [CNC Controller]
    ```
    """)
