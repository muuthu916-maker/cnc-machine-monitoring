@echo off
title PS025 - Streamlit Dashboard Launcher [Sakthi Hackathon 2.0]
color 0B

echo ==============================================================================
echo       PS025 - PREDICTIVE TOOL-LIFE MONITORING AND OPTIMIZATION SYSTEM
echo                 FULL STREAMLIT & PLOTLY DASHBOARD LAUNCHER
echo ==============================================================================
echo.

where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PY_CMD=python
    goto :PYTHON_FOUND
)

where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    set PY_CMD=py
    goto :PYTHON_FOUND
)

echo [ERROR] Python not found in PATH!
pause
exit /b 1

:PYTHON_FOUND
echo [1/2] Installing / verifying required libraries (Streamlit, Plotly, Pandas, NumPy)...
%PY_CMD% -m pip install -r requirements.txt

echo.
echo [2/2] Launching Streamlit Industrial Monitoring Dashboard...
%PY_CMD% -m streamlit run app.py --server.port 8501 --server.address 0.0.0.0
pause
